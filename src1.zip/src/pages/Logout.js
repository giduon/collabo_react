function App() {

    useEffect (()=> {
        const url = '${API_BASE_URL}/member/logout';

        axios.post(url)
        .then()
        .catch();
        
    }, []);

    return (
        <>
            메뉴 아이템
        </>
    );
}

export default App;