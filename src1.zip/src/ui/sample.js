function App() {
    return (
        <>
            메뉴 아이템
        </>
    );
}

export default App;